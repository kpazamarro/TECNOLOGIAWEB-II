<?php
include_once "../modelo/modPersona.php";
 if($method=="POST"){
$nombres=$data->nombres;
$papellido=$data->papellido;
$sapellido=$data->$sapellido;
$persona=new persona();
$persona->setNombre($nombres);
$persona->setPapellido($papellido);
$persona->setSapellido($sapellido);
$persona->registrarPersona();
}
